package com.elad.halacha.profiles.store

import com.elad.halacha.profiles.api.Profile
import com.elad.halacha.profiles.api.Labels
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue

/**
 * Simple classpath-backed store. It loads JSONs from resources/profiles/*.json
 * (same place the REST API used).
*/
object ProfileStore {
private val mapper: ObjectMapper = jacksonObjectMapper().registerModule(JavaTimeModule())
private val pathPrefix = "profiles/"

data class Entry(val key: String, val displayName: String, val labels: Labels?)

fun list(): List<Entry> {
val loader = Thread.currentThread().contextClassLoader
val dirUrl = loader.getResource(pathPrefix) ?: return emptyList()
val dir = java.io.File(dirUrl.toURI())
if (!dir.exists()) return emptyList()
return dir.listFiles { f -> f.extension == "json" }?.mapNotNull { file ->
try {
val p: Profile = mapper.readValue(file)
Entry(p.key, p.displayName, p.labels)
} catch (_: Exception) { null }
} ?: emptyList()
}

fun get(key: String): Profile? {
val loader = Thread.currentThread().contextClassLoader
val url = loader.getResource("$pathPrefix$key.json") ?: return null
val txt = url.readText()
return mapper.readValue(txt)
}
}