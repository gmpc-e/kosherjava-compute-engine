package com.elad.halacha.engine.internal

/**
 * Canonical IDs for internal (composite) calculations that are NOT direct
 * method calls on KosherJava classes.
 *
 * Namespaced by shita/family to avoid collisions.
 */
enum class InternalMethodId(val id: String, val display: String) {
    // Sfaradi / Or HaChaim examples
    SFORH_ALOS_72_ZMANIYOT_ASTRO(
        "SFARADI_OR_HACHAIM.ALOS_72_ZMANIYOT_ASTRO",
        "Alot HaShachar – 72 proportional minutes before astronomical sunrise (18°)"
    ),
    SFORH_MISHEYAKIR_SHAOT_ZMANIYOT_ASTRO(
        "SFARADI_OR_HACHAIM.MISHEYAKIR_SHAOT_ZMANIYOT_ASTRO",
        "Misheyakir / Tallit–Tefillin by proportional minutes from astronomical sunrise (18°)"
    ),
    SFORH_SOF_ZMAN_SHMA_MGA_72_ZMANIYOT_ASTRO(
        "SFARADI_OR_HACHAIM.SOF_ZMAN_SHMA_MGA_72_ZMANIYOT_ASTRO",
        "Sof Zman Kriat Shema (MGA) using 72 proportional minutes / astronomical day (18°)"
    ),
    SFORH_TZAIS_VARIANTS_DEGREES_4_9(
        "SFARADI_OR_HACHAIM.TZAIS_4_9_DEGREES",
        "Tzait HaKochavim at 4.9° solar depression"

    ),
    // --- New: Sof Zman Kriat Shema / Tefillah variants ---

    // 3 shaot zmaniyot from start of the ASTRO (18°) day
    SFORH_SOF_ZMAN_SHMA_GRA_ASTRO(
        "SFARADI_OR_HACHAIM.SOF_ZMAN_SHMA_GRA_ASTRO",
        "Sof Zman Kriat Shema (Gra/Baal HaTanya): 3 zmaniyot hours; day = ASTRO(18°) sunrise → ASTRO(18°) sunset"
    ),

    // 4 shaot zmaniyot from start of expanded ASTRO day (±72 zmaniyot minutes)
    SFORH_SOF_ZMAN_TEFILLA_MGA_72_ZMANIYOT_ASTRO(
        "SFARADI_OR_HACHAIM.SOF_ZMAN_TEFILLA_MGA_72_ZMANIYOT_ASTRO",
        "Sof Zman Tefillah (MGA): 4 zmaniyot hours; day = ASTRO(18°) expanded by ±72 zmaniyot minutes"
    ),

    // 4 shaot zmaniyot from start of the ASTRO (18°) day
    SFORH_SOF_ZMAN_TEFILLA_GRA_ASTRO(
        "SFARADI_OR_HACHAIM.SOF_ZMAN_TEFILLA_GRA_ASTRO",
        "Sof Zman Tefillah (Gra/Baal HaTanya): 4 zmaniyot hours; day = ASTRO(18°) sunrise → ASTRO(18°) sunset"
    );


    companion object {
        fun from(id: String): InternalMethodId? = entries.firstOrNull { it.id == id }
    }
}