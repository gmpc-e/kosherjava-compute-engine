package com.elad.halacha.profiles.api

/** Simple i18n label holder (optional). */
data class Labels(
    val en: String? = null,
    val he: String? = null
)

/** Minimal profile metadata for list UIs. */
data class ProfileSummary(
    val key: String,
    val displayName: String,
    val labels: Labels? = null
)

/** Geo + TZ input used by compute calls. */
data class GeoInput(
    val lat: Double,
    val lon: Double,
    val elev: Double = 0.0,
    val tz: String
)

/** Compute input (date as YYYY-MM-DD string + geo). */
data class ProfileComputeInput(
    val dateIso: String,
    val geo: GeoInput
)

/** How a time was resolved. Mirrors REST, kept minimal. */
data class Resolution(
    val kind: String,                  // "EXTERNAL_NAME" | "INTERNAL"
    val externalMethod: String? = null,
    val internalMethodId: String? = null,
    val owner: String? = null,         // e.g. "ComplexZmanimCalendar" or "INTERNAL"
    val status: String? = null         // e.g. "ok" | "unresolved" | "missing_id" | "error"
)

/** A single computed time line item. */
data class ProfileComputeItem(
    val id: String,
    val label: Labels? = null,
    val resolution: Resolution,
    val utc: String?,                  // ISO ZonedDateTime string (UTC zone)
    val local: String?,                // ISO ZonedDateTime string (input tz)
    val instant: String?               // Instant string
)

/** Validator warning (copied from REST shape, pared down). */
data class ValidationWarning(
    val path: String,
    val code: String,
    val message: String
)

/** Top-level compute response. */
data class ProfileComputeResponse(
    val profile: ProfileSummary,
    val input: ProfileComputeInput,
    val results: List<ProfileComputeItem>,
    val warnings: List<ValidationWarning> = emptyList()
)