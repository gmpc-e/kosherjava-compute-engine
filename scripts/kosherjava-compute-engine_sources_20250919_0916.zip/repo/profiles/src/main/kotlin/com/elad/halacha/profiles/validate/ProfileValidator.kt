package com.elad.halacha.profiles.validate

import com.elad.halacha.profiles.api.*

object ProfileValidator {
    fun validate(p: Profile): ValidationResponse {
        val errors = mutableListOf<ValidationError>()
        val warnings = mutableListOf<ValidationWarning>()

        if (p.version != 1) {
            warnings += ValidationWarning("$.version", "unknown_version", "Version ${p.version} not tested")
        }
        if (p.key.isBlank()) {
            errors += ValidationError("$.key", "missing_key", "Profile key is required")
        }
        if (p.times.isEmpty()) {
            errors += ValidationError("$.times", "empty_times", "No times configured")
        }

        p.times.forEachIndexed { idx, t ->
            val base = "$.times[$idx]"
            if (t.id.isBlank()) {
                errors += ValidationError("$base.id", "missing_id", "Each time needs an id")
            }
            when (t.target.kind) {
                "EXTERNAL_NAME" -> {
                    if (t.target.externalMethod.isNullOrBlank()) {
                        errors += ValidationError("$base.target.externalMethod", "missing", "externalMethod required")
                    }
                }
                "INTERNAL" -> {
                    if (t.target.internalMethodId.isNullOrBlank()) {
                        errors += ValidationError("$base.target.internalMethodId", "missing", "internalMethodId required")
                    } else {
                        warnings += ValidationWarning(
                            "$base.target.internalMethodId",
                            "unknown_internal_method",
                            "Internal method '${t.target.internalMethodId}' may be unregistered; will be resolved at compute"
                        )
                    }
                }
                else -> {
                    errors += ValidationError("$base.target.kind", "unsupported_kind", "Kind must be EXTERNAL_NAME or INTERNAL")
                }
            }
        }

        return ValidationResponse(errors.isEmpty(), errors, warnings)
    }
}