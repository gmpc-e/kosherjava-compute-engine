package com.elad.halacha.profiles.api

import com.elad.halacha.rest.profiles.*
import com.elad.halacha.engine.compute.MethodRegistry
import com.elad.halacha.engine.compute.ZmanimComputer
import com.elad.halacha.engine.model.ComputeMethod
import com.elad.halacha.engine.model.ComputeRequest
import com.elad.halacha.engine.internal.InternalMethodRegistry
import com.kosherjava.zmanim.util.GeoLocation
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.TimeZone

/** App-facing, in-process API to list/validate/compute profiles (no HTTP required). */
interface ProfilesService {
    fun listProfiles(): List<MinimalProfileInfo>
    fun getProfile(key: String): Profile?
    fun validateProfile(profile: Profile): ValidationResponse

    /** Compute a stored profile by key. */
    fun computeProfileByKey(
        key: String,
        dateIso: String,
        tz: String,
        lat: Double,
        lon: Double,
        elevMeters: Double = 0.0
    ): ProfileComputeResponse

    /** Compute an ad-hoc profile value (not stored in ProfileStore). */
    fun computeProfile(
        profile: Profile,
        dateIso: String,
        tz: String,
        lat: Double,
        lon: Double,
        elevMeters: Double = 0.0
    ): ProfileComputeResponse
}

/** Default implementation that reuses existing engine components. */
class DefaultProfilesService : ProfilesService {

    override fun listProfiles(): List<MinimalProfileInfo> =
        ProfileStore.list().map { MinimalProfileInfo(it.key, it.displayName) }

    override fun getProfile(key: String): Profile? = ProfileStore.get(key)

    override fun validateProfile(profile: Profile): ValidationResponse =
        ProfileValidator.validate(profile)

    override fun computeProfileByKey(
        key: String,
        dateIso: String,
        tz: String,
        lat: Double,
        lon: Double,
        elevMeters: Double
    ): ProfileComputeResponse {
        val profile = getProfile(key)
            ?: return ProfileComputeResponse(
                profile = MinimalProfileInfo(key, "(missing)"),
                input = ProfileComputeInput(dateIso, GeoInput(lat, lon, elevMeters, tz)),
                results = emptyList(),
                warnings = listOf(
                    ValidationWarning("$.key", "not_found", "Profile '$key' not found")
                )
            )
        return computeProfile(profile, dateIso, tz, lat, lon, elevMeters)
    }

    override fun computeProfile(
        profile: Profile,
        dateIso: String,
        tz: String,
        lat: Double,
        lon: Double,
        elevMeters: Double
    ): ProfileComputeResponse {

        val validation = ProfileValidator.validate(profile)
        val zoneId = ZoneId.of(tz)
        val geoloc = GeoLocation("request", lat, lon, elevMeters, TimeZone.getTimeZone(zoneId))
        val dateInstant = LocalDate.parse(dateIso).atStartOfDay(zoneId).toInstant()
        val requestDate = Date.from(dateInstant)

        val results: List<ProfileComputeItem> = profile.times.map { t ->
            when (t.target.kind) {
                "EXTERNAL_NAME" -> {
                    val name = t.target.externalMethod!!
                    val req = ComputeRequest(
                        method = ComputeMethod.SUNSET, // ignored by by-name path
                        dateIso = dateIso,
                        lat = lat,
                        lon = lon,
                        elevationMeters = elevMeters,
                        tz = tz
                    )
                    val r = ZmanimComputer.computeByExternalName(name, req)
                    val owner = MethodRegistry.resolve(name)?.owner
                    ProfileComputeItem(
                        id = t.id,
                        label = t.label,
                        resolution = Resolution(
                            kind = "EXTERNAL_NAME",
                            externalMethod = name,
                            owner = owner
                        ),
                        utc = r.utc,
                        local = r.local,
                        instant = r.instant?.toString()
                    )
                }

                "INTERNAL" -> {
                    val internalId = t.target.internalMethodId
                    if (internalId.isNullOrBlank()) {
                        ProfileComputeItem(
                            id = t.id,
                            label = t.label,
                            resolution = Resolution(
                                kind = "INTERNAL",
                                internalMethodId = null,
                                owner = "INTERNAL",
                                status = "missing_id"
                            ),
                            utc = null,
                            local = null,
                            instant = null
                        )
                    } else {
                        val out = runCatching {
                            InternalMethodRegistry.compute(
                                idString = internalId,
                                date = requestDate,
                                loc = geoloc,
                                params = t.target.params ?: emptyMap()
                            )
                        }.getOrElse {
                            return@map ProfileComputeItem(
                                id = t.id,
                                label = t.label,
                                resolution = Resolution(
                                    kind = "INTERNAL",
                                    internalMethodId = internalId,
                                    owner = "INTERNAL",
                                    status = "error"
                                ),
                                utc = null,
                                local = null,
                                instant = null
                            )
                        }

                        val computed = out.time
                        if (computed == null) {
                            ProfileComputeItem(
                                id = t.id,
                                label = t.label,
                                resolution = Resolution(
                                    kind = "INTERNAL",
                                    internalMethodId = internalId,
                                    owner = "INTERNAL",
                                    status = "unresolved"
                                ),
                                utc = null,
                                local = null,
                                instant = null
                            )
                        } else {
                            val instant = computed.toInstant()
                            ProfileComputeItem(
                                id = t.id,
                                label = t.label,
                                resolution = Resolution(
                                    kind = "INTERNAL",
                                    internalMethodId = internalId,
                                    owner = "INTERNAL",
                                    status = "ok"
                                ),
                                utc = instant.atZone(ZoneId.of("UTC")).toString(),
                                local = instant.atZone(zoneId).toString(),
                                instant = instant.toString()
                            )
                        }
                    }
                }

                else -> {
                    ProfileComputeItem(
                        id = t.id,
                        label = t.label,
                        resolution = Resolution(
                            kind = "UNKNOWN",
                            externalMethod = t.target.externalMethod,
                            internalMethodId = t.target.internalMethodId,
                            owner = null,
                            status = "unsupported_kind"
                        ),
                        utc = null, local = null, instant = null
                    )
                }
            }
        }

        return ProfileComputeResponse(
            profile = MinimalProfileInfo(profile.key, profile.displayName),
            input = ProfileComputeInput(
                dateIso = dateIso,
                geo = GeoInput(lat, lon, elevMeters, tz)
            ),
            results = results,
            warnings = validation.warnings
        )
    }
}