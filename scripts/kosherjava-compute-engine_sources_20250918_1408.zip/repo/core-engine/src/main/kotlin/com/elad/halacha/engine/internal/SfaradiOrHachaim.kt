package com.elad.halacha.engine.internal

import com.elad.halacha.engine.internal.InternalMethodComputer.Inputs
import com.elad.halacha.engine.internal.InternalMethodId.*
import com.kosherjava.zmanim.util.GeoLocation
import java.util.Date

object SfaradiOrHachaim {

    data class Params(
        val astroDegrees: Double? = null,
        // You can support either minutes OR hours; here we use hours for MISHEYAKIR.
        val misheyakirOffsetHoursFromSeaLevelSunrise: Double? = null
    )

    fun compute(id: InternalMethodId, date: Date, loc: GeoLocation, params: Params = Params()): InternalMethodComputer.Output {
        val inputs = Inputs(date, loc, params.astroDegrees ?: 18.0)
        val time: Date? = when (id) {
            SFORH_ALOS_72_ZMANIYOT_ASTRO ->
                InternalMethodComputer.alotByProportionalMinutesBeforeSeaLevelSunrise(inputs, 72.0)

            SFORH_MISHEYAKIR_SHAOT_ZMANIYOT_ASTRO ->
                InternalMethodComputer.misheyakirByProportionalHours(
                    inputs,
                    params.misheyakirOffsetHoursFromSeaLevelSunrise ?: -1.1
                )

            SFORH_SOF_ZMAN_SHMA_MGA_72_ZMANIYOT_ASTRO ->
                InternalMethodComputer.sofZmanShmaMGA72ZmaniyotAstro(inputs)

            SFORH_TZAIS_VARIANTS_DEGREES_4_9 ->
                InternalMethodComputer.tzaisByDegrees(inputs, 4.9)
            SFORH_SOF_ZMAN_SHMA_GRA_ASTRO ->
                InternalMethodComputer.sofZmanShmaGraAstro(inputs)

            SFORH_SOF_ZMAN_TEFILLA_MGA_72_ZMANIYOT_ASTRO ->
                InternalMethodComputer.sofZmanTefillaMga72ZmaniyotAstro(inputs)

            SFORH_SOF_ZMAN_TEFILLA_GRA_ASTRO ->
                InternalMethodComputer.sofZmanTefillaGraAstro(inputs)
        }
        return InternalMethodComputer.Output(id, time)
    }
}