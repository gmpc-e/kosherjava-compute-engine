package com.elad.halacha.profiles.api

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

// ---- Profile JSON structure (shared) ----

data class Profile(
    val version: Int,
    val key: String,
    val displayName: String,
    val labels: Labels? = null,
    val times: List<ProfileTime>
)

data class Labels(
    val en: String? = null,
    val he: String? = null
)

data class ProfileTime(
    val id: String,
    val label: Labels? = null,
    val target: Target
)

@JsonIgnoreProperties(ignoreUnknown = true)
data class Target(
    val kind: String,                             // "EXTERNAL_NAME" | "INTERNAL"
    val externalMethod: String? = null,           // for EXTERNAL_NAME
    val internalMethodId: String? = null,         // for INTERNAL
    val params: Map<String, Any?>? = null         // optional tuning for internal methods
)

// ---- Validation result (shared) ----

data class ValidationResponse(
    val valid: Boolean,
    val errors: List<ValidationError> = emptyList(),
    val warnings: List<ValidationWarning> = emptyList()
)

data class ValidationError(
    val path: String,
    val code: String,
    val message: String
)

data class ValidationWarning(
    val path: String,
    val code: String,
    val message: String
)

// ---- In-process compute I/O (shared) ----

data class MinimalProfileInfo(
    val key: String,
    val displayName: String,
    val labels: Labels? = null
)

data class GeoInput(
    val lat: Double,
    val lon: Double,
    val elev: Double,
    val tz: String
)

data class ProfileComputeInput(
    val dateIso: String,
    val geo: GeoInput
)

data class Resolution(
    val kind: String,                // "EXTERNAL_NAME" | "INTERNAL"
    val externalMethod: String? = null,
    val internalMethodId: String? = null,
    val owner: String? = null,
    val status: String? = null       // "ok" | "unresolved" | "missing_id" | "error"
)

data class ProfileComputeItem(
    val id: String,
    val label: Labels? = null,
    val resolution: Resolution,
    val utc: String?,     // Zoned string or null
    val local: String?,   // Zoned string or null
    val instant: String?  // Instant string or null
)

data class ProfileComputeResponse(
    val profile: MinimalProfileInfo,
    val input: ProfileComputeInput,
    val results: List<ProfileComputeItem>,
    val warnings: List<ValidationWarning> = emptyList()
)