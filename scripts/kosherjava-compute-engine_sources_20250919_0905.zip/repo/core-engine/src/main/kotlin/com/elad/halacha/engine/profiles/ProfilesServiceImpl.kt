package com.elad.halacha.engine.profiles

import com.elad.halacha.engine.compute.MethodRegistry
import com.elad.halacha.engine.compute.ZmanimComputer
import com.elad.halacha.engine.model.ComputeMethod
import com.elad.halacha.engine.model.ComputeRequest
import com.elad.halacha.engine.internal.InternalMethodRegistry
import com.elad.halacha.profiles.ProfileStore
import com.elad.halacha.rest.profiles.ProfileValidator
import com.elad.halacha.rest.profiles.Profile as StoredProfile
import com.elad.halacha.rest.profiles.Labels as StoredLabels
import com.elad.halacha.profiles.api.*
import com.kosherjava.zmanim.util.GeoLocation
import org.slf4j.LoggerFactory
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.TimeZone

/**
 * Engine-side implementation of the in-process ProfilesService API.
 * Uses existing ProfileStore / Validator / ZmanimComputer / InternalMethodRegistry.
 */
class ProfilesServiceImpl : com.elad.halacha.profiles.api.ProfilesService {

    private val log = LoggerFactory.getLogger(ProfilesServiceImpl::class.java)

    // ---- Public API ----

    override fun listProfiles(): List<ProfileSummary> =
        ProfileStore.list().map { it.toSummary() }

    override fun computeProfile(
        key: String,
        input: ProfileComputeInput
    ): ProfileComputeResponse {
        val profile: StoredProfile = ProfileStore.get(key)
            ?: error("Profile '$key' not found")

        val validation = ProfileValidator.validate(profile)
        val zoneId = ZoneId.of(input.geo.tz)

        val results = profile.times.map { t ->
            when (t.target.kind) {
                "EXTERNAL_NAME" -> {
                    val name = t.target.externalMethod
                        ?: return@map t.missingExternalItem()

                    // Build compute request; by-name ignores enum
                    val req = ComputeRequest(
                        method = ComputeMethod.SUNSET,
                        dateIso = input.dateIso,
                        lat = input.geo.lat,
                        lon = input.geo.lon,
                        elevationMeters = input.geo.elev,
                        tz = input.geo.tz
                    )
                    val r = ZmanimComputer.computeByExternalName(name, req)
                    val owner = MethodRegistry.resolve(name)?.owner

                    ProfileComputeItem(
                        id = t.id,
                        label = t.label?.toApiLabels(),
                        resolution = Resolution(
                            kind = "EXTERNAL_NAME",
                            externalMethod = name,
                            owner = owner
                        ),
                        utc = r.utc,
                        local = r.local,
                        instant = r.instant?.toString()
                    )
                }

                "INTERNAL" -> {
                    val internalId = t.target.internalMethodId
                    if (internalId.isNullOrBlank()) {
                        return@map ProfileComputeItem(
                            id = t.id,
                            label = t.label?.toApiLabels(),
                            resolution = Resolution(
                                kind = "INTERNAL",
                                internalMethodId = null,
                                owner = "INTERNAL",
                                status = "missing_id"
                            ),
                            utc = null,
                            local = null,
                            instant = null
                        )
                    }

                    val geoloc = GeoLocation(
                        "request",
                        input.geo.lat,
                        input.geo.lon,
                        input.geo.elev,
                        TimeZone.getTimeZone(zoneId)
                    )
                    val dateInstant = LocalDate.parse(input.dateIso)
                        .atStartOfDay(zoneId).toInstant()

                    val out = runCatching {
                        InternalMethodRegistry.compute(
                            idString = internalId,
                            date = Date.from(dateInstant),
                            loc = geoloc,
                            params = t.target.params ?: emptyMap()
                        )
                    }.onFailure { ex ->
                        log.warn("Internal compute '{}' failed: {}", internalId, ex.message)
                    }.getOrNull()

                    val computed = out?.time
                    if (computed == null) {
                        ProfileComputeItem(
                            id = t.id,
                            label = t.label?.toApiLabels(),
                            resolution = Resolution(
                                kind = "INTERNAL",
                                internalMethodId = internalId,
                                owner = "INTERNAL",
                                status = "unresolved"
                            ),
                            utc = null,
                            local = null,
                            instant = null
                        )
                    } else {
                        val instant = computed.toInstant()
                        ProfileComputeItem(
                            id = t.id,
                            label = t.label?.toApiLabels(),
                            resolution = Resolution(
                                kind = "INTERNAL",
                                internalMethodId = internalId,
                                owner = "INTERNAL",
                                status = "ok"
                            ),
                            utc = instant.atZone(ZoneId.of("UTC")).toString(),
                            local = instant.atZone(zoneId).toString(),
                            instant = instant.toString()
                        )
                    }
                }

                else -> {
                    // Unknown kind → return unresolved
                    ProfileComputeItem(
                        id = t.id,
                        label = t.label?.toApiLabels(),
                        resolution = Resolution(
                            kind = t.target.kind,
                            owner = "UNKNOWN",
                            status = "unsupported_kind"
                        ),
                        utc = null,
                        local = null,
                        instant = null
                    )
                }
            }
        }

        return ProfileComputeResponse(
            profile = profile.toSummary(),
            input = input,
            results = results,
            warnings = validation.warnings.map {
                ValidationWarning(it.path, it.code, it.message)
            }
        )
    }

    // ---- Mappers / helpers ----

    private fun StoredLabels.toApiLabels(): Labels =
        Labels(en = this.en, he = this.he)

    private fun StoredProfile.toSummary(): ProfileSummary =
        ProfileSummary(
            key = this.key,
            displayName = this.displayName,
            labels = this.labels?.toApiLabels()
        )

    private fun com.elad.halacha.rest.profiles.ProfileTime.missingExternalItem() =
        ProfileComputeItem(
            id = this.id,
            label = this.label?.toApiLabels(),
            resolution = Resolution(
                kind = "EXTERNAL_NAME",
                externalMethod = null,
                owner = null,
                status = "missing_method"
            ),
            utc = null,
            local = null,
            instant = null
        )
}