package com.elad.halacha.profiles.api

import com.elad.halacha.profiles.store.ProfileStore
import com.elad.halacha.profiles.validate.ProfileValidator
import com.elad.halacha.engine.compute.MethodRegistry
import com.elad.halacha.engine.compute.ZmanimComputer
import com.elad.halacha.engine.model.ComputeMethod
import com.elad.halacha.engine.model.ComputeRequest
import com.elad.halacha.engine.internal.InternalMethodRegistry
import com.kosherjava.zmanim.util.GeoLocation
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.TimeZone

/**
 * In-process profile service API (shared with Android demo).
 * Implementation lives in core-engine.
 */
interface ProfilesService {
    fun listProfiles(): List<MinimalProfileInfo>
    fun getProfile(key: String): Profile?
    fun validate(profile: Profile): ValidationResponse
    fun computeProfile(
        key: String,
        dateIso: String,
        lat: Double,
        lon: Double,
        elev: Double,
        tz: String
    ): ProfileComputeResponse
}

/**
 * Default implementation is provided by core-engine (see ProfilesServiceImpl).
 * This companion is just a convenience finder.
 */
object Profiles {
    // You may wire a DI container; for now assume core-engine registers the impl
    @Volatile private var instance: ProfilesService? = null
    fun register(service: ProfilesService) { instance = service }
    fun service(): ProfilesService = requireNotNull(instance) { "ProfilesService not registered" }
}

/* Utilities that both impls may want */
internal fun computeExternalByName(
    name: String,
    input: ProfileComputeInput
): ProfileComputeItem {
    val req = ComputeRequest(
        method = ComputeMethod.SUNSET, // ignored by by-name
        dateIso = input.dateIso,
        lat = input.geo.lat,
        lon = input.geo.lon,
        elevationMeters = input.geo.elev,
        tz = input.geo.tz
    )
    val r = ZmanimComputer.computeByExternalName(name, req)
    val owner = MethodRegistry.resolve(name)?.owner
    return ProfileComputeItem(
        id = "", // caller fills
        label = null,
        resolution = Resolution(
            kind = "EXTERNAL_NAME",
            externalMethod = name,
            owner = owner
        ),
        utc = r.utc,
        local = r.local,
        instant = r.instant?.toString()
    )
}

internal fun computeInternalById(
    internalId: String,
    params: Map<String, Any?>?,
    input: ProfileComputeInput
): ProfileComputeItem {
    val zoneId = ZoneId.of(input.geo.tz)
    val geoloc = GeoLocation(
        "request",
        input.geo.lat,
        input.geo.lon,
        input.geo.elev,
        TimeZone.getTimeZone(zoneId)
    )
    val dateInstant = LocalDate.parse(input.dateIso).atStartOfDay(zoneId).toInstant()

    val out = runCatching {
        InternalMethodRegistry.compute(
            idString = internalId,
            date = Date.from(dateInstant),
            loc = geoloc,
            params = params ?: emptyMap()
        )
    }.getOrNull()

    val computed = out?.time
    return if (computed == null) {
        ProfileComputeItem(
            id = "",
            label = null,
            resolution = Resolution(
                kind = "INTERNAL",
                internalMethodId = internalId,
                owner = "INTERNAL",
                status = "unresolved"
            ),
            utc = null, local = null, instant = null
        )
    } else {
        val instant = computed.toInstant()
        ProfileComputeItem(
            id = "",
            label = null,
            resolution = Resolution(
                kind = "INTERNAL",
                internalMethodId = internalId,
                owner = "INTERNAL",
                status = "ok"
            ),
            utc = instant.atZone(ZoneId.of("UTC")).toString(),
            local = instant.atZone(zoneId).toString(),
            instant = instant.toString()
        )
    }
}