package com.elad.halacha.engine.profiles

import com.elad.halacha.profiles.api.*
import com.elad.halacha.profiles.store.ProfileStore
import com.elad.halacha.profiles.validate.ProfileValidator
import com.elad.halacha.engine.compute.MethodRegistry
import com.elad.halacha.engine.compute.ZmanimComputer
import com.elad.halacha.engine.model.ComputeMethod
import com.elad.halacha.engine.model.ComputeRequest
import com.elad.halacha.engine.internal.InternalMethodRegistry
import com.kosherjava.zmanim.util.GeoLocation
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.TimeZone

/**
 * Concrete in-process implementation that the Android demo can call directly.
 */
class ProfilesServiceImpl : ProfilesService {

    override fun listProfiles(): List<MinimalProfileInfo> =
        ProfileStore.list().map { MinimalProfileInfo(it.key, it.displayName, it.labels) }

    override fun getProfile(key: String): Profile? = ProfileStore.get(key)

    override fun validate(profile: Profile): ValidationResponse =
        ProfileValidator.validate(profile)

    override fun computeProfile(
        key: String,
        dateIso: String,
        lat: Double,
        lon: Double,
        elev: Double,
        tz: String
    ): ProfileComputeResponse {
        val profile = requireNotNull(ProfileStore.get(key)) { "Profile '$key' not found" }
        val validation = ProfileValidator.validate(profile)

        val input = ProfileComputeInput(
            dateIso = dateIso,
            geo = GeoInput(lat = lat, lon = lon, elev = elev, tz = tz)
        )

        val results = profile.times.map { t ->
            when (t.target.kind) {
                "EXTERNAL_NAME" -> {
                    val name = t.target.externalMethod!!
                    val req = ComputeRequest(
                        method = ComputeMethod.SUNSET, // ignored in by-name
                        dateIso = dateIso,
                        lat = lat,
                        lon = lon,
                        elevationMeters = elev,
                        tz = tz
                    )
                    val r = ZmanimComputer.computeByExternalName(name, req)
                    val owner = MethodRegistry.resolve(name)?.owner
                    ProfileComputeItem(
                        id = t.id,
                        label = t.label,
                        resolution = Resolution(
                            kind = "EXTERNAL_NAME",
                            externalMethod = name,
                            owner = owner
                        ),
                        utc = r.utc,
                        local = r.local,
                        instant = r.instant?.toString()
                    )
                }
                "INTERNAL" -> {
                    val internalId = t.target.internalMethodId
                    if (internalId.isNullOrBlank()) {
                        ProfileComputeItem(
                            id = t.id,
                            label = t.label,
                            resolution = Resolution(
                                kind = "INTERNAL",
                                internalMethodId = null,
                                owner = "INTERNAL",
                                status = "missing_id"
                            ),
                            utc = null, local = null, instant = null
                        )
                    } else {
                        val zoneId = ZoneId.of(tz)
                        val geoloc = GeoLocation("request", lat, lon, elev, TimeZone.getTimeZone(zoneId))
                        val dateInstant = LocalDate.parse(dateIso).atStartOfDay(zoneId).toInstant()

                        val out = runCatching {
                            InternalMethodRegistry.compute(
                                idString = internalId,
                                date = Date.from(dateInstant),
                                loc = geoloc,
                                params = t.target.params ?: emptyMap()
                            )
                        }.getOrNull()

                        val computed = out?.time
                        if (computed == null) {
                            ProfileComputeItem(
                                id = t.id,
                                label = t.label,
                                resolution = Resolution(
                                    kind = "INTERNAL",
                                    internalMethodId = internalId,
                                    owner = "INTERNAL",
                                    status = "unresolved"
                                ),
                                utc = null, local = null, instant = null
                            )
                        } else {
                            val instant = computed.toInstant()
                            ProfileComputeItem(
                                id = t.id,
                                label = t.label,
                                resolution = Resolution(
                                    kind = "INTERNAL",
                                    internalMethodId = internalId,
                                    owner = "INTERNAL",
                                    status = "ok"
                                ),
                                utc = instant.atZone(ZoneId.of("UTC")).toString(),
                                local = instant.atZone(zoneId).toString(),
                                instant = instant.toString()
                            )
                        }
                    }
                }
                else -> {
                    ProfileComputeItem(
                        id = t.id,
                        label = t.label,
                        resolution = Resolution(
                            kind = t.target.kind,
                            owner = "UNKNOWN",
                            status = "error"
                        ),
                        utc = null, local = null, instant = null
                    )
                }
            }
        }

        return ProfileComputeResponse(
            profile = MinimalProfileInfo(profile.key, profile.displayName, profile.labels),
            input = input,
            results = results,
            warnings = validation.warnings
        )
    }
}