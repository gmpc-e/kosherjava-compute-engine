package com.elad.halacha.rest.profiles

import com.elad.halacha.engine.compute.MethodRegistry
import com.elad.halacha.engine.internal.InternalMethodRegistry
import org.slf4j.LoggerFactory

/**
 * Validates a Profile object (version 1).
 *
 * Rules:
 * - version must be 1
 * - key: [A-Za-z0-9_-], length 1..40
 * - times: at least 1
 * - each time.id unique, same pattern 1..40
 * - label: optional, but warn if both he/en missing
 * - target:
 *      EXTERNAL_NAME -> externalMethod must exist in MethodRegistry
 *      INTERNAL      -> internalMethodId must exist in InternalMethodRegistry
 */
object ProfileValidator {

    private val log = LoggerFactory.getLogger(ProfileValidator::class.java)

    fun validate(profile: Profile): ValidationResponse {
        val errors = mutableListOf<ValidationError>()
        val warnings = mutableListOf<ValidationWarning>()

        log.debug("Starting validation for profile key='{}', version={}", profile.key, profile.version)

        // version
        if (profile.version != 1) {
            errors += ValidationError("$.version", "unsupported_version", "Only version=1 is supported")
        }

        // key
        val keyOk = Regex("^[A-Za-z0-9_-]{1,40}$").matches(profile.key)
        if (!keyOk) {
            errors += ValidationError("$.key", "invalid_key", "Allowed: [A-Za-z0-9_-], length 1-40")
        }

        // times
        if (profile.times.isEmpty()) {
            errors += ValidationError("$.times", "empty_times", "At least one time entry is required")
        }

        // Prepare lookups
        val internalIds: Set<String> = InternalMethodRegistry.all.map { it.id }.toSet()

        // unique time ids
        val seen = mutableSetOf<String>()
        profile.times.forEachIndexed { idx, t ->
            val path = "$.times[$idx]"
            log.debug("Validating time entry [{}]: id='{}', kind='{}'", idx, t.id, t.target.kind)

            // time.id
            val idOk = Regex("^[A-Za-z0-9_-]{1,40}$").matches(t.id)
            if (!idOk) {
                errors += ValidationError("$path.id", "invalid_id", "Allowed: [A-Za-z0-9_-], length 1-40")
            }
            if (!seen.add(t.id)) {
                errors += ValidationError("$path.id", "duplicate_id", "Duplicate time id '${t.id}'")
            }

            // label
            val he = t.label?.he
            val en = t.label?.en
            if ((he == null || he.isBlank()) && (en == null || en.isBlank())) {
                warnings += ValidationWarning("$path.label", "missing_label", "Provide 'he' or 'en' for better UX")
            }

            // target
            when (t.target.kind) {
                "EXTERNAL_NAME" -> {
                    val name = t.target.externalMethod
                    if (name.isNullOrBlank()) {
                        errors += ValidationError(
                            "$path.target.externalMethod",
                            "missing_external_method",
                            "Required for kind=EXTERNAL_NAME"
                        )
                    } else {
                        val found = MethodRegistry.resolve(name)
                        if (found == null) {
                            errors += ValidationError(
                                "$path.target.externalMethod",
                                "unknown_external_method",
                                "Method '$name' not found in registry"
                            )
                        }
                    }
                }

                // Inside the "INTERNAL" branch in ProfileValidator.validate:
                "INTERNAL" -> {
                    val internalId = t.target.internalMethodId
                    if (internalId.isNullOrBlank()) {
                        errors += ValidationError(
                            "$path.target.internalMethodId",
                            "missing_internal_id",
                            "Required for kind=INTERNAL"
                        )
                    } else if (internalId !in internalIds) {
                        errors += ValidationError(
                            "$path.target.internalMethodId",
                            "unknown_internal_method",
                            "Internal method '$internalId' is not registered"
                        )
                    }
                    // Accept params
                    val params = t.target.params
                    if (params != null) {
                        if (params !is Map<*, *>) {
                            warnings += ValidationWarning(
                                "$path.target.params",
                                "invalid_params_type",
                                "Params should be a JSON object"
                            )
                        } else {
                            // Optionally warn for unknown keys (example, if you have allowedKeys)
                            val allowedKeys = InternalMethodRegistry.getAllowedParamsKeys(internalId)
                            val unknownKeys = params.keys.filter { it !in allowedKeys }
                            if (unknownKeys.isNotEmpty()) {
                                warnings += ValidationWarning(
                                    "$path.target.params",
                                    "unknown_param_keys",
                                    "Unknown param keys: ${unknownKeys.joinToString(",")}"
                                )
                            }
                        }
                    }
                }
            }
        }

        log.debug("Validation complete: {} errors, {} warnings", errors.size, warnings.size)
        return ValidationResponse(errors.isEmpty(), errors, warnings)
    }
}