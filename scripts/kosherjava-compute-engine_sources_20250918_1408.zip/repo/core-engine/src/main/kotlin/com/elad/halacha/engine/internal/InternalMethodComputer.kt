package com.elad.halacha.engine.internal

import com.kosherjava.zmanim.AstronomicalCalendar
import com.kosherjava.zmanim.util.GeoLocation
import org.slf4j.LoggerFactory
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.TimeZone
import kotlin.math.roundToLong

object InternalMethodComputer {

    private val log = LoggerFactory.getLogger(InternalMethodComputer::class.java)
    private val isoFmt = DateTimeFormatter.ISO_OFFSET_DATE_TIME

    data class Inputs(
        val date: Date,
        val location: GeoLocation,
        /**
         * Default depression for degree-based twilight (used only by degree targets).
         * Note: The base day for ALOS/MISHEYAKIR in this bundle is sea-level sunrise/sunset.
         */
        val astroDegrees: Double = 18.0
    )

    data class Output(val id: InternalMethodId, val time: Date?)

    private fun Date?.fmt(tz: TimeZone): String =
        this?.toInstant()?.atZone(ZoneId.of(tz.id))?.let { isoFmt.format(it) } ?: "null"

    private fun millisToHms(ms: Long): String {
        val totalSec = (ms / 1000.0).roundToLong()
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return String.format("%02d:%02d:%02d", h, m, s)
    }

    // ---------- Baselines ----------

    /** Sea-level sunrise/sunset for this date/location (netz/shkiah, no elevation). */
    private fun seaLevelRiseSet(inputs: Inputs): Pair<Date, Date>? {
        val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }
        val tz = inputs.location.timeZone

        val sunrise = ac.seaLevelSunrise
        val sunset  = ac.seaLevelSunset
        if (sunrise == null || sunset == null || !sunset.after(sunrise)) return null

        log.debug(
            "# Sea-level Sunrise: {} (local {}), method: AstronomicalCalendar.getSeaLevelSunrise()",
            sunrise.toInstant().atZone(ZoneId.of("UTC")),
            sunrise.fmt(tz)
        )
        log.debug(
            "# Sea-level Sunset: {} (local {}), method: AstronomicalCalendar.getSeaLevelSunset()",
            sunset.toInstant().atZone(ZoneId.of("UTC")),
            sunset.fmt(tz)
        )
        return sunrise to sunset
    }

    /** ASTRO(18°) sunrise/sunset for this date/location. */
    private fun astroRiseSet18(inputs: Inputs): Pair<Date, Date>? {
        val tz = inputs.location.timeZone
        val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }
        val zenith = AstronomicalCalendar.GEOMETRIC_ZENITH + inputs.astroDegrees

        val rise = ac.getSunriseOffsetByDegrees(zenith)
        val set  = ac.getSunsetOffsetByDegrees(zenith)
        if (rise == null || set == null || !set.after(rise)) return null

        log.debug("# Baseline: ASTRO_{}° (AstronomicalCalendar.getSunrise/SetOffsetByDegrees)", inputs.astroDegrees)
        log.debug("# Astro Sunrise: {} (local {})", rise.toInstant().atZone(ZoneId.of("UTC")), rise.fmt(tz))
        log.debug("# Astro Sunset : {} (local {})", set.toInstant().atZone(ZoneId.of("UTC")), set.fmt(tz))
        return rise to set
    }

    // ---------- Zmanit helpers ----------

    /** Shaah zmanit from *sea-level* day (netz→shkiah). */
    fun shaahZmanitSeaLevel(inputs: Inputs): Long {
        val (sunrise, sunset) = seaLevelRiseSet(inputs) ?: error(
            "Sea-level sunrise/sunset unavailable for ${inputs.date} at ${inputs.location}."
        )
        val dayMillis = sunset.time - sunrise.time
        val shaah = dayMillis / 12L
        log.debug(
            "# [Sea-level day] dayLength={} ({}), shaahZmanit={} ({} min)",
            dayMillis, millisToHms(dayMillis), shaah, "%.3f".format(shaah / 60000.0)
        )
        return shaah
    }

    /** Solve shaah zmanit for the *expanded astronomical day* (MGA 72 zmaniyot at both ends). */
    private fun shaahZmanitAstroExpanded72(inputs: Inputs): Long {
        val (sunriseA, sunsetA) = astroRiseSet18(inputs) ?: error(
            "Astronomical sunrise/sunset unavailable for ${inputs.date} at ${inputs.location}."
        )
        val base = sunsetA.time - sunriseA.time
        val k = 2.0 * (72.0 / 60.0) // add 72 zmanit min at both ends → 2 * 1.2 = 2.4
        val shaah = (base / (12.0 - k)).roundToLong()

        log.debug(
            "# [Astro expanded day] base={} ({}), k={}, shaahZmanitSolved={} ({} min)",
            base, millisToHms(base), k, shaah, "%.3f".format(shaah / 60000.0)
        )

        val tz = inputs.location.timeZone
        val alos = Date(sunriseA.time - (1.2 * shaah).roundToLong())
        val tzais = Date(sunsetA.time + (1.2 * shaah).roundToLong())
        val expandedLen = tzais.time - alos.time

        log.debug(
            "# [Astro expanded day] ALOS(expanded)={} (UTC {}), TZAIS(expanded)={} (UTC {}), expandedLength={} ({})",
            alos.fmt(tz), alos.toInstant().atZone(ZoneId.of("UTC")),
            tzais.fmt(tz), tzais.toInstant().atZone(ZoneId.of("UTC")),
            expandedLen, millisToHms(expandedLen)
        )
        return shaah
    }

    // ---------- Offsets ----------

    /** Offset any base time by N *zmaniyot minutes* (N * shaah/60). Negative = before. */
    fun offsetByProportionalMinutes(base: Date, shaahZmanitMs: Long, minutes: Double): Date {
        val perMinMs = shaahZmanitMs / 60.0
        val deltaMs = minutes * perMinMs
        return Date(base.time + deltaMs.roundToLong())
    }

    /** Offset any base time by H *zmaniyot hours* (H * shaah). Negative = before. */
    fun offsetByProportionalHours(base: Date, shaahZmanitMs: Long, hours: Double): Date {
        val deltaMs = (hours * shaahZmanitMs.toDouble()).roundToLong()
        return Date(base.time + deltaMs)
    }

    // ---------- Methods ----------

    /** Misheyakir by **zmaniyot hours** relative to *sea-level* sunrise (default −1.1h). */
    fun misheyakirByProportionalHours(inputs: Inputs, hoursFromSunrise: Double = -1.1): Date? {
        val tz = inputs.location.timeZone
        val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }

        val sunrise = ac.seaLevelSunrise ?: return null
        val shaah = shaahZmanitSeaLevel(inputs)

        log.debug(
            "# Computing internal method: MISHEYAKIR by {} zmanit hours from Sea-level Sunrise ({})",
            hoursFromSunrise, sunrise.fmt(tz)
        )
        log.debug("# Formula: misheyakir = seaLevelSunrise + ({} * shaahZmanit)", hoursFromSunrise)

        val result = offsetByProportionalHours(sunrise, shaah, hoursFromSunrise)
        log.debug(
            "# Result: MISHEYAKIR = {} (UTC {})",
            result.fmt(tz), result.toInstant().atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /** ALOS by **72 zmaniyot minutes before** *sea-level* sunrise. */
    fun alotByProportionalMinutesBeforeSeaLevelSunrise(inputs: Inputs, minutes: Double): Date? {
        val tz = inputs.location.timeZone
        val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }

        val sunrise = ac.seaLevelSunrise ?: return null
        val shaah = shaahZmanitSeaLevel(inputs)

        log.debug(
            "# Computing internal method: ALOS by {} proportional minutes BEFORE Sea-level Sunrise ({})",
            minutes, sunrise.fmt(tz)
        )
        log.debug("# Formula: alos = seaLevelSunrise - ({} zmanit minutes)", minutes)

        val result = offsetByProportionalMinutes(sunrise, shaah, -minutes)
        log.debug(
            "# Result for \"{}\" = {} (UTC {})",
            InternalMethodId.SFORH_ALOS_72_ZMANIYOT_ASTRO.id,
            result.fmt(tz), result.toInstant().atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /** TZAIS by *degree* depression (e.g., 4.9°). */
    fun tzaisByDegrees(inputs: Inputs, degrees: Double): Date? {
        val tz = inputs.location.timeZone
        val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }
        val zenith = AstronomicalCalendar.GEOMETRIC_ZENITH + degrees

        log.debug(
            "# Computing internal method: TZAIS at {}° depression; method: AstronomicalCalendar.getSunsetOffsetByDegrees({})",
            degrees, zenith
        )

        val result = ac.getSunsetOffsetByDegrees(zenith)
        log.debug(
            "# Result: TZAIS({}°) = {} (UTC {})",
            degrees, result.fmt(tz), result?.toInstant()?.atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /**
     * Sof Zman Shma (MGA): end of the 3rd zmanit hour of the **expanded day**,
     * where the day is defined as:
     *   start = baselineSunrise − 72 zmaniyot minutes ( = −1.2 · shaah )
     *   end   = baselineSunset  + 72 zmaniyot minutes ( = +1.2 · shaah )
     *
     * => shaah = (baselineSunset − baselineSunrise) / 9.6
     * => SZ"S  = start + 3·shaah
     *
     * Baseline default here: SEA_LEVEL (per your last request).
     */
    fun sofZmanShmaMGA72ZmaniyotAstro(
        inputs: Inputs,
        baseline: Baseline = Baseline.SEA_LEVEL
    ): Date? {
        val tz = inputs.location.timeZone

        // 1) Pick baseline sunrise/sunset (SEA_LEVEL or ASTRO_18°)
        val (rise, set) = when (baseline) {
            Baseline.SEA_LEVEL -> {
                val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }
                val sr = ac.seaLevelSunrise
                val ss = ac.seaLevelSunset
                log.debug("# Baseline: SEA_LEVEL (AstronomicalCalendar.getSeaLevelSunrise / getSeaLevelSunset)")
                log.debug("# Baseline Sunrise: {} (local {})", sr?.toInstant()?.atZone(ZoneId.of("UTC")), sr.fmt(tz))
                log.debug("# Baseline Sunset:  {} (local {})", ss?.toInstant()?.atZone(ZoneId.of("UTC")), ss.fmt(tz))
                sr to ss
            }
            Baseline.ASTRO_18 -> {
                val ac = AstronomicalCalendar(inputs.location).apply { calendar.time = inputs.date }
                val zenith = AstronomicalCalendar.GEOMETRIC_ZENITH + inputs.astroDegrees
                val sr = ac.getSunriseOffsetByDegrees(zenith)
                val ss = ac.getSunsetOffsetByDegrees(zenith)
                log.debug("# Baseline: ASTRO_{}° (AstronomicalCalendar.getSunrise/SetOffsetByDegrees)", inputs.astroDegrees)
                log.debug("# Baseline Sunrise: {} (local {})", sr?.toInstant()?.atZone(ZoneId.of("UTC")), sr.fmt(tz))
                log.debug("# Baseline Sunset:  {} (local {})", ss?.toInstant()?.atZone(ZoneId.of("UTC")), ss.fmt(tz))
                sr to ss
            }
        }

        rise ?: return null
        set  ?: return null
        require(set.after(rise)) { "Baseline sunset must be after sunrise" }

        // 2) Solve shaah for expanded day: shaah = (set - rise) / 9.6
        val baseLen = set.time - rise.time
        val shaah   = (baseLen / 9.6).roundToLong()
        log.debug(
            "# Expanded-day shaah: baseLen={} ({}), shaah={} ({} min)",
            baseLen, millisToHms(baseLen), shaah, "%.3f".format(shaah / 60000.0)
        )

        // 3) Expanded start/end
        val start = Date(rise.time - (1.2 * shaah).roundToLong())
        val end   = Date(set.time  + (1.2 * shaah).roundToLong())
        val expLen = end.time - start.time
        log.debug(
            "# Expanded day: start={} (UTC {}), end={} (UTC {}), len={} ({})",
            start.fmt(tz), start.toInstant().atZone(ZoneId.of("UTC")),
            end.fmt(tz), end.toInstant().atZone(ZoneId.of("UTC")),
            expLen, millisToHms(expLen)
        )

        // 4) End of 3rd zmanit hour: start + 3·shaah
        val result = Date(start.time + (3.0 * shaah).roundToLong())
        log.debug(
            "# SZ\"S (MGA): start + 3·shaah = {} (UTC {})",
            result.fmt(tz), result.toInstant().atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /** Sof Zman Kriat Shema (Gra/Tanya): 3 zmaniyot hours; day = SEA-LEVEL sunrise→sunset. */
    fun sofZmanShmaGraAstro(inputs: Inputs): Date? {
        val tz = inputs.location.timeZone
        val (rise, set) = seaLevelRiseSet(inputs) ?: return null
        val baseLen = set.time - rise.time
        val shaah = baseLen / 12L

        log.debug(
            "# SZ\"S Gra (SEA-LEVEL): shaah=base/12 → base={} ({}), shaah={} ({} min)",
            baseLen, millisToHms(baseLen), shaah, "%.3f".format(shaah / 60000.0)
        )
        log.debug("# Baseline: SEA_LEVEL (AstronomicalCalendar.getSeaLevelSunrise / getSeaLevelSunset)")

        val result = Date(rise.time + 3L * shaah)
        log.debug(
            "# SZ\"S Gra = sunrise + 3·shaah = {} (UTC {})",
            result.fmt(tz), result.toInstant().atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /** Sof Zman Tefillah (MGA): 4 zmaniyot hours; day = SEA-LEVEL expanded by ±72 *zmaniyot* minutes. */
    fun sofZmanTefillaMga72ZmaniyotAstro(inputs: Inputs): Date? {
        val tz = inputs.location.timeZone
        val (rise, set) = seaLevelRiseSet(inputs) ?: return null
        val baseLen = set.time - rise.time

        // Expanded sea-level day, ±72 *zmaniyot* minutes ⇒ shaah = base/9.6 ; start = rise - 1.2·shaah
        val shaah = (baseLen / 9.6).roundToLong()
        val start = Date(rise.time - (1.2 * shaah).roundToLong())

        log.debug(
            "# SZ\"T MGA (SEA-LEVEL expanded): shaah=base/9.6 → base={} ({}), shaah={} ({} min)",
            baseLen, millisToHms(baseLen), shaah, "%.3f".format(shaah / 60000.0)
        )
        log.debug(
            "# Expanded start = seaLevelSunrise - 1.2·shaah = {} (UTC {})",
            start.fmt(tz), start.toInstant().atZone(ZoneId.of("UTC"))
        )

        val result = Date(start.time + 4L * shaah)
        log.debug(
            "# SZ\"T MGA = start + 4·shaah = {} (UTC {})",
            result.fmt(tz), result.toInstant().atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /** Sof Zman Tefillah (Gra/Tanya): 4 zmaniyot hours; day = SEA-LEVEL sunrise→sunset. */
    fun sofZmanTefillaGraAstro(inputs: Inputs): Date? {
        val tz = inputs.location.timeZone
        val (rise, set) = seaLevelRiseSet(inputs) ?: return null
        val baseLen = set.time - rise.time
        val shaah = baseLen / 12L

        log.debug(
            "# SZ\"T Gra (SEA-LEVEL): shaah=base/12 → base={} ({}), shaah={} ({} min)",
            baseLen, millisToHms(baseLen), shaah, "%.3f".format(shaah / 60000.0)
        )
        log.debug("# Baseline: SEA_LEVEL (AstronomicalCalendar.getSeaLevelSunrise / getSeaLevelSunset)")

        val result = Date(rise.time + 4L * shaah)
        log.debug(
            "# SZ\"T Gra = sunrise + 4·shaah = {} (UTC {})",
            result.fmt(tz), result.toInstant().atZone(ZoneId.of("UTC"))
        )
        return result
    }

    /** Which baseline defines sunrise/sunset for the expanded day. */
    enum class Baseline { SEA_LEVEL, ASTRO_18 }
}